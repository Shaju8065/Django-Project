import pymysql
from pymongo import MongoClient
from django.shortcuts import render


class EmpOperations:
    def addnewemployee(self,custId,carType,custName,carName, cityName,Price,Mobilenum):
        status=None
        try:
            con=pymysql.connect(host='bwhi9tgmciqdnqidftqa-mysql.services.clever-cloud.com',user='ua76mfassmwczyly',password='Ydvss4Uh9wudTv7RCasm',database='bwhi9tgmciqdnqidftqa')
            curs=con.cursor()
            curs.execute("insert into newcar(cstId,car,cstName,carNm, cityNm,price,mobnum) values('%.2f','%s','%s','%s', '%s','%s','%s')" %(custId, carType, custName, carName, cityName,Price,Mobilenum))
            con.commit()
            con.close()
            status='success'
        except:
            status='error'
        
        return status
    
    def getreportdata(self):
        con=pymysql.connect(host='b7ynlwm9vi4twzsxsu9f-mysql.services.clever-cloud.com',user='udsypi8l3ys4ac0q',password='A4qUKkNz34O2aiQ46dk6',database='b7ynlwm9vi4twzsxsu9f')
        curs=con.cursor()
        curs.execute("select * from employee")
        data=curs.fetchall()
        return data
    

    def addnewworker(self,id,nm,dp,ps,lo,sl):
        status=None
        try:
            client=MongoClient("mongodb+srv://sharayu:mongodb913@ethancluster.npsn31t.mongodb.net/?retryWrites=true&w=majority")
            db=client["praffulldb"]
            coll=db["workers"]
            dic={}
            dic['_id']=id
            dic['name']=nm
            dic['dept']=dp
            dic['post']=ps
            dic['location']=lo
            dic['salary']=sl

            coll.insert_one(dic)
            status='success'
        except Exception as err:
            print(err)
            status='error'
        
        return status

    def allworkers(self):
        client=MongoClient("mongodb+srv://sharayu:mongodb913@ethancluster.npsn31t.mongodb.net/?retryWrites=true&w=majority")
        db=client["praffulldb"]
        coll=db["students"]
        dic={}
        dic['data']=coll.find()
        return dic




    # def getreportdata(self):
    #     con=pymysql.connect(host='b7ynlwm9vi4twzsxsu9f-mysql.services.clever-cloud.com',user='udsypi8l3ys4ac0q',password='A4qUKkNz34O2aiQ46dk6',database='b7ynlwm9vi4twzsxsu9f')
    #     curs=con.cursor()
    #     curs.execute("select * from newcar")
    #     data=curs.fetchall()
    #     return data


    def getreportdata(self):
        con = None  # Initialize the 'con' variable outside the try block
        try:
            con = pymysql.connect(host='b7ynlwm9vi4twzsxsu9f-mysql.services.clever-cloud.com',user='ua76mfassmwczyly',password='Ydvss4Uh9wudTv7RCasm',database='bwhi9tgmciqdnqidftqa')
            with con.cursor() as curs:
                curs.execute("SELECT * FROM newcar")
                data = curs.fetchall()
                print(data)
            return data
        except pymysql.Error as e:
            print("Error:", e)
            return []
        finally:
            if con:
                con.close()
